import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { fixtureSnapshot } from "./fixtures";
import type { CommerceAdapter, CommerceSnapshot } from "./types";
import { useWorkspacePreferences } from '@/lib/workspace-preferences';
export const exampleAdapter: CommerceAdapter = { loadSnapshot: async () => fixtureSnapshot };
const CommerceContext = createContext<{
  snapshot: CommerceSnapshot;
  adapter: CommerceAdapter;
  changedStages: Set<string>;
  refreshSnapshot: () => Promise<void>;
  refreshing: boolean;
  error?: string | undefined;
}>({ snapshot: fixtureSnapshot, adapter: exampleAdapter, changedStages: new Set(), refreshSnapshot: async () => {}, refreshing: false });
export function CommerceProvider({
  children,
  adapter = exampleAdapter,
}: {
  children: ReactNode;
  adapter?: CommerceAdapter;
}) {
  const [snapshot, setSnapshot] = useState<CommerceSnapshot>(fixtureSnapshot);
  const [changedStages, setChangedStages] = useState<Set<string>>(new Set());
  const [error, setError] = useState<string>();
  const [refreshing, setRefreshing] = useState(false);
  const { preferences } = useWorkspacePreferences();
  const refreshSnapshot = async () => {
    setRefreshing(true);
    try {
      const data = await adapter.loadSnapshot();
      previous.current = data;
      setSnapshot(data);
      setChangedStages(new Set());
      setError(undefined);
    } catch { setError('The source could not be refreshed. The last snapshot remains visible.'); }
    finally { setRefreshing(false); }
  };
  const previous = useRef<CommerceSnapshot | undefined>(undefined);
  useEffect(() => {
    let active = true;
    previous.current = undefined;
    adapter
      .loadSnapshot()
      .then((data) => {
        if (active) {
          previous.current = data;
          setSnapshot(data);
          setChangedStages(new Set());
        }
      })
      .catch(() => {
        if (active)
          setError("The connected source could not be loaded. Example data remains visible.");
      });
    const unsubscribe = preferences.refresh === 'subscription' ? adapter.subscribe?.((next) => {
      if (!active) return;
      const changes = new Set<string>();
      if (previous.current && next.source === "backend")
        for (const w of next.workflows)
          for (const stage of w.stages) {
            const old = previous.current.workflows
              .find((item) => item.id === w.id)
              ?.stages.find((item) => item.id === stage.id);
            if (old && (old.status !== stage.status || old.verdict !== stage.verdict))
              changes.add(`${w.id}:${stage.id}`);
          }
      previous.current = next;
      setSnapshot(next);
      setChangedStages(changes);
    }) : undefined;
    return () => {
      active = false;
      unsubscribe?.();
    };
  }, [adapter, preferences.refresh]);
  return (
    <CommerceContext.Provider value={{ snapshot, adapter, changedStages, error, refreshing, refreshSnapshot }}>
      {children}
    </CommerceContext.Provider>
  );
}
export const useCommerce = () => useContext(CommerceContext);
