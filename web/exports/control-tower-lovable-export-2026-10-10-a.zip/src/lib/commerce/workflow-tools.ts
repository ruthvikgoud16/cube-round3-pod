import type { Workflow } from './types';
export function matchesWorkflow(workflow: Workflow, query: string) {
  const text = [workflow.id, workflow.product, workflow.sku, workflow.unit, workflow.route, workflow.status, workflow.outcome, workflow.decision, workflow.reviewReason, ...workflow.stages.flatMap(stage => [stage.name, stage.agent, stage.verdict, stage.explanation, ...stage.evidence.flatMap(e => [e.id, e.label, e.hash, ...e.upstream])])].join(' ').toLowerCase();
  return query.toLowerCase().trim().split(/\s+/).every(term => text.includes(term));
}
export function reviewCaseState(workflow: Workflow) {
  if (workflow.override) return 'OVERRIDE RECORDED';
  if (workflow.stages.some(stage => stage.status === 'SERVICE_UNAVAILABLE')) return 'SERVICE BLOCKED';
  if (workflow.stages.some(stage => !!stage.error || stage.status === 'BLOCKED')) return 'EVIDENCE BLOCKED';
  return 'AWAITING REVIEW';
}