import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
export interface SavedView { id: string; name: string; search: string; status: string; outcome: string }
interface Preferences { theme: 'light' | 'dark'; density: 'comfortable' | 'compact'; reducedMotion: boolean; refresh: 'manual' | 'subscription'; views: SavedView[] }
const defaults: Preferences = { theme: 'dark', density: 'comfortable', reducedMotion: false, refresh: 'subscription', views: [] };
const Context = createContext<{ preferences: Preferences; update: (patch: Partial<Preferences>) => void }>({ preferences: defaults, update: () => {} });
export function WorkspacePreferencesProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState(defaults);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      const stored: unknown = JSON.parse(localStorage.getItem('cube-workspace-preferences') || 'null');
      if (stored && typeof stored === 'object') {
        const value = stored as Record<string, unknown>;
        const views = Array.isArray(value['views']) ? value['views'].filter((view): view is SavedView => !!view && typeof view === 'object' && ['id', 'name', 'search', 'status', 'outcome'].every(key => typeof (view as Record<string, unknown>)[key] === 'string')) : [];
        setPreferences({ theme: value['theme'] === 'light' ? 'light' : 'dark', density: value['density'] === 'compact' ? 'compact' : 'comfortable', reducedMotion: value['reducedMotion'] === true, refresh: value['refresh'] === 'manual' ? 'manual' : 'subscription', views });
      } else if (localStorage.getItem('cube-appearance') === 'light') setPreferences({ ...defaults, theme: 'light' });
    } catch { /* Invalid or unavailable browser storage does not block the console. */ }
    setReady(true);
  }, []);
  useEffect(() => {
    if (!ready) return;
    const root = document.documentElement;
    root.dataset['theme'] = preferences.theme;
    root.dataset['density'] = preferences.density;
    root.dataset['motion'] = preferences.reducedMotion ? 'reduced' : 'system';
    root.classList.toggle('dark', preferences.theme === 'dark');
    try { localStorage.setItem('cube-workspace-preferences', JSON.stringify(preferences)); localStorage.setItem('cube-appearance', preferences.theme); } catch { /* Session controls work without persistence. */ }
  }, [preferences, ready]);
  return <Context.Provider value={{ preferences, update: patch => setPreferences(current => ({ ...current, ...patch })) }}>{children}</Context.Provider>;
}
export const useWorkspacePreferences = () => useContext(Context);