import { describe, expect, it } from 'vitest';
import { fixtureSnapshot } from '@/lib/commerce/fixtures';
import { matchesWorkflow, reviewCaseState } from '@/lib/commerce/workflow-tools';
describe('Workspace inspection tools', () => {
  it('matches multiple terms across workflow and evidence context', () => {
    const workflow = fixtureSnapshot.workflows[0];
    if (!workflow) throw new Error('Expected fixture');
    expect(matchesWorkflow(workflow, `${workflow.id} ${workflow.product}`)).toBe(true);
    expect(matchesWorkflow(workflow, `${workflow.id} unknown-evidence-term`)).toBe(false);
    const upstream = workflow.stages.flatMap(s => s.evidence.flatMap(e => e.upstream))[0];
    if (upstream) expect(matchesWorkflow(workflow, upstream)).toBe(true);
  });
  it('derives blocked cases from supplied states without changing the workflow', () => {
    const workflow = fixtureSnapshot.workflows[0];
    if (!workflow) throw new Error('Expected fixture');
    const unavailable = { ...workflow, override: undefined, stages: workflow.stages.map(s => ({ ...s, status: 'SERVICE_UNAVAILABLE' as const })) };
    // Optional override is omitted rather than manufactured.
    const { override: _ignored, ...caseData } = unavailable;
    expect(reviewCaseState(caseData)).toBe('SERVICE BLOCKED');
    expect(reviewCaseState({ ...caseData, stages: caseData.stages.map(s => ({ ...s, status: 'BLOCKED' as const })) })).toBe('EVIDENCE BLOCKED');
    expect(reviewCaseState({ ...caseData, override: { actor: 'Returned backend actor', reason: 'Returned reason', timestamp: '2026-10-10T00:00:00Z' } })).toBe('OVERRIDE RECORDED');
  });
});