import { useState } from 'react';
import { ChevronDown, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCommerce } from '@/lib/commerce/service';
import { useWorkspacePreferences } from '@/lib/workspace-preferences';
import { StatusBadge } from './primitives';
export function ServiceConfiguration() {
  const [open, setOpen] = useState(false);
  const { snapshot, adapter, refreshSnapshot, refreshing, error } = useCommerce();
  const { preferences } = useWorkspacePreferences();
  return <section className="settings-section service-configuration"><div className="feature-heading"><h2>Service configuration</h2><Button variant="outline" size="sm" aria-expanded={open} onClick={() => setOpen(!open)}>Configuration <ChevronDown size={14} /></Button></div>
    <div className="setting-row"><strong>Integration source</strong><StatusBadge value={snapshot.source === 'example' ? 'EXAMPLE / NOT CONNECTED' : 'BACKEND DATA'} /></div>
    {open && <dl className="configuration-dl"><dt>Snapshot reads</dt><dd>Available through commerce adapter</dd><dt>Source subscription</dt><dd>{adapter.subscribe ? 'Available' : 'Not supplied'}</dd><dt>Update preference</dt><dd>{preferences.refresh === 'manual' ? 'Manual snapshot reads' : adapter.subscribe ? 'Subscribed to source events' : 'Source events unavailable'}</dd><dt>Human overrides</dt><dd>{adapter.submitOverride ? 'Backend action available' : 'Not supplied · read-only review'}</dd><dt>Endpoint configuration</dt><dd>Owned by your existing integration; no endpoint is inferred or edited here.</dd><dt>Credentials</dt><dd>Not displayed in this workspace</dd></dl>}
    <div className="setting-row"><span className="subtle-note">{snapshot.source === 'example' ? 'Refresh reloads the same labeled fixtures.' : 'Refresh requests a snapshot from the connected source.'}</span><Button variant="ghost" size="sm" onClick={refreshSnapshot} disabled={refreshing}><RefreshCw size={14} />{refreshing ? 'Refreshing…' : 'Refresh source'}</Button></div>{error && <p role="alert">{error}</p>}
  </section>;
}