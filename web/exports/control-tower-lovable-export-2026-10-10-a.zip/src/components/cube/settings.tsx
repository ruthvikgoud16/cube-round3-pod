import { RefreshCw, Sun, Moon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { useWorkspacePreferences } from '@/lib/workspace-preferences';
import { useCommerce } from '@/lib/commerce/service';
import { PageHeading } from './overview';
import { ServiceConfiguration } from './service-configuration';
export function SettingsPage() {
  const { preferences, update } = useWorkspacePreferences();
  const { refreshSnapshot, refreshing } = useCommerce();
  return <><PageHeading title="System settings" subtitle="Your workspace, your operating preferences." />
    <section className="settings-section"><h2>Appearance</h2>
      <div className="setting-row"><div><strong>Color environment</strong><span>Mineral light / petrol dark</span></div><div className="segmented-tabs">{(['light', 'dark'] as const).map(theme => <Button key={theme} variant="ghost" className={preferences.theme === theme ? 'active' : ''} aria-pressed={preferences.theme === theme} onClick={() => update({ theme })}>{theme === 'light' ? <Sun size={15} /> : <Moon size={15} />}{theme === 'light' ? 'Light' : 'Dark'}</Button>)}</div></div>
      <div className="setting-row"><strong>Display density</strong><select aria-label="Display density" value={preferences.density} onChange={e => update({ density: e.target.value === 'compact' ? 'compact' : 'comfortable' })}><option value="comfortable">Comfortable</option><option value="compact">Compact</option></select></div>
      <div className="setting-row"><div><strong>Reduce motion</strong><span>System accessibility preferences always apply.</span></div><Switch aria-label="Reduce motion" checked={preferences.reducedMotion} onCheckedChange={reducedMotion => update({ reducedMotion })} /></div>
    </section>
    <section className="settings-section"><h2>Data updates</h2><div className="setting-row"><div><strong>Refresh preference</strong><span>No polling or simulated activity.</span></div><select aria-label="Refresh preference" value={preferences.refresh} onChange={e => update({ refresh: e.target.value === 'manual' ? 'manual' : 'subscription' })}><option value="subscription">Receive source updates</option><option value="manual">Manual snapshots only</option></select></div><div className="setting-row"><strong>Reload source snapshot</strong><Button variant="outline" onClick={refreshSnapshot} disabled={refreshing}><RefreshCw size={15} />{refreshing ? 'Refreshing…' : 'Refresh snapshot'}</Button></div></section>
    <ServiceConfiguration />
  </>;
}