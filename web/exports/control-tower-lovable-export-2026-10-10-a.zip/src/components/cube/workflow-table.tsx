import { useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Search,
  SlidersHorizontal,
  ArrowUpDown,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  GitBranch,
  Box,
  Keyboard,
  Cable,
  Watch,
  BookmarkPlus,
  Trash2,
  Columns2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Workflow } from "@/lib/commerce/types";
import { StatusBadge } from "./primitives";
import { useWorkspacePreferences } from '@/lib/workspace-preferences';
import { matchesWorkflow } from '@/lib/commerce/workflow-tools';
import { WorkflowComparison } from './workflow-comparison';
const statuses = ["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED", "BLOCKED", "RECOVERY_REQUIRED"];
export function ProductSymbol({ name }: { name: string }) {
  const Icon = name.includes("Keyboard")
    ? Keyboard
    : name.includes("Hub")
      ? Cable
      : name.includes("Watch")
        ? Watch
        : Box;
  return (
    <span className="product-symbol">
      <Icon size={18} />
    </span>
  );
}
export function WorkflowTable({
  workflows,
  limit = 5,
  onSelect,
  selectedId,
}: {
  workflows: Workflow[];
  limit?: number;
  onSelect?: (workflow: Workflow) => void;
  selectedId?: string | undefined;
}) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("ALL");
  const [outcome, setOutcome] = useState("ALL");
  const [filters, setFilters] = useState(false);
  const [page, setPage] = useState(0);
  const [ascending, setAscending] = useState(false);
  const { preferences, update } = useWorkspacePreferences();
  const [viewName, setViewName] = useState('');
  const [selectedView, setSelectedView] = useState('');
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [comparing, setComparing] = useState(false);
  const [toolNotice, setToolNotice] = useState('');
  const filtered = workflows
    .filter(
      (w) =>
        matchesWorkflow(w, search) &&
        (status === "ALL" || w.status === status) &&
        (outcome === "ALL" || w.outcome === outcome),
    )
    .sort((a, b) => (ascending ? a.id.localeCompare(b.id) : b.id.localeCompare(a.id)));
  const maxPage = Math.max(0, Math.ceil(filtered.length / limit) - 1);
  const safePage = Math.min(page, maxPage);
  const rows = filtered.slice(safePage * limit, (safePage + 1) * limit);
  return (
    <div className="workflow-table-section">
      <div className="table-controls">
        <div className="table-tabs">
          <Button
            variant="ghost"
            className={status === "ALL" ? "table-tab active" : "table-tab"}
            onClick={() => {
              setStatus("ALL");
              setPage(0);
            }}
          >
            All workflows <span>{workflows.length}</span>
          </Button>
          <Button
            variant="ghost"
            className={status === "IN_PROGRESS" ? "table-tab active" : "table-tab"}
            onClick={() => {
              setStatus("IN_PROGRESS");
              setPage(0);
            }}
          >
            In progress
          </Button>
          <Button
            variant="ghost"
            className={status === "BLOCKED" ? "table-tab active" : "table-tab"}
            onClick={() => {
              setStatus("BLOCKED");
              setPage(0);
            }}
          >
            Blocked
          </Button>
        </div>
        <div className="table-search-tools">
          <label className="search-field">
            <Search size={15} />
            <input
              aria-label="Search workflows"
              placeholder="Search product, route, evidence…"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(0);
              }}
            />
          </label>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setFilters(!filters)}
            aria-expanded={filters}
          >
            <SlidersHorizontal />
            Filters
          </Button>
        </div>
      </div>
      <div className="workflow-tool-bar">
        <select aria-label="Saved workflow views" value={selectedView} onChange={e => { setSelectedView(e.target.value); const view = preferences.views.find(v => v.id === e.target.value); if (view) { setSearch(view.search); setStatus(view.status); setOutcome(view.outcome); setPage(0); } }}><option value="">Saved views</option>{preferences.views.map(view => <option key={view.id} value={view.id}>{view.name}</option>)}</select>
        <input aria-label="Saved view name" placeholder="Name this view" value={viewName} onChange={e => setViewName(e.target.value)} />
        <Button variant="ghost" size="icon" title="Save current filters" aria-label="Save current filters" disabled={!viewName.trim()} onClick={() => { const id = crypto.randomUUID(); update({ views: [...preferences.views, { id, name: viewName.trim(), search, status, outcome }] }); setSelectedView(id); setViewName(''); setToolNotice('View saved on this device.'); }}><BookmarkPlus size={15} /></Button>
        <Button variant="ghost" size="icon" title="Delete saved view" aria-label="Delete saved view" disabled={!selectedView} onClick={() => { update({ views: preferences.views.filter(v => v.id !== selectedView) }); setSelectedView(''); setToolNotice('Saved view removed.'); }}><Trash2 size={15} /></Button>
        <Button variant="outline" size="sm" disabled={compareIds.length !== 2} onClick={() => setComparing(true)}><Columns2 size={15} />Compare ({compareIds.length}/2)</Button>
        {compareIds.length > 0 && <Button variant="ghost" size="sm" onClick={() => setCompareIds([])}>Clear selection</Button>}
        <span className="subtle-note" role="status">{toolNotice}</span>
      </div>
      {filters && (
        <div className="filter-row">
          <label>
            Status
            <select
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(0);
              }}
            >
              <option value="ALL">All statuses</option>
              {statuses.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <label>
            Final outcome
            <select
              value={outcome}
              onChange={(e) => {
                setOutcome(e.target.value);
                setPage(0);
              }}
            >
              <option value="ALL">All outcomes</option>
              {["CLEAN", "EXCEPTION", "INCOMPLETE", "NEEDS_REVIEW", "CLAIM_RECOMMENDED"].map(
                (s) => (
                  <option key={s}>{s}</option>
                ),
              )}
            </select>
          </label>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setSearch("");
              setStatus("ALL");
              setOutcome("ALL");
            }}
          >
            Reset
          </Button>
        </div>
      )}
      <div className="table-scroll">
        <table className="workflow-table">
          <thead>
            <tr>
              <th><span className="sr-only">Compare selection</span></th>
              <th>
                <Button variant="ghost" size="sm" onClick={() => setAscending(!ascending)}>
                  Workflow ID <ArrowUpDown size={12} />
                </Button>
              </th>
              <th>Product / Unit</th>
              <th>Route</th>
              <th>Workflow status</th>
              <th>Final outcome</th>
              <th>Updated (UTC)</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {rows.map((w) => (
              <tr key={w.id} className={selectedId === w.id ? "row-selected" : ""}>
                <td><input type="checkbox" aria-label={`Compare ${w.id}`} checked={compareIds.includes(w.id)} disabled={compareIds.length === 2 && !compareIds.includes(w.id)} onChange={e => setCompareIds(current => e.target.checked ? [...current, w.id] : current.filter(id => id !== w.id))} /></td>
                <td>
                  {onSelect ? (
                    <Button variant="link" className="workflow-id" onClick={() => onSelect(w)}>
                      {w.id}
                    </Button>
                  ) : (
                    <Link
                      className="workflow-id"
                      to="/workflows/$workflowId"
                      params={{ workflowId: w.id }}
                    >
                      {w.id}
                    </Link>
                  )}
                </td>
                <td>
                  <div className="table-product">
                    <ProductSymbol name={w.product} />
                    <div>
                      <strong>{w.product}</strong>
                      <code>
                        {w.sku} <span>·</span> {w.unit}
                      </code>
                    </div>
                  </div>
                </td>
                <td>
                  <span className="route-cell">
                    <GitBranch size={12} />
                    {w.route}
                  </span>
                </td>
                <td>
                  <StatusBadge value={w.status} small />
                </td>
                <td>
                  <StatusBadge value={w.outcome} small />
                </td>
                <td className="time-cell">{w.updated.slice(11, 16)}</td>
                <td>
                  <Button asChild variant="ghost" size="icon" title={`Open ${w.id}`}>
                    <Link
                      to="/workflows/$workflowId"
                      params={{ workflowId: w.id }}
                      aria-label={`Open ${w.id}`}
                    >
                      <ArrowUpRight />
                    </Link>
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!rows.length && (
          <div className="empty-state">
            <Search size={24} />
            <strong>No workflows match these filters</strong>
            <Button
              variant="link"
              onClick={() => {
                setSearch("");
                setStatus("ALL");
                setOutcome("ALL");
              }}
            >
              Clear filters
            </Button>
          </div>
        )}
      </div>
      <div className="table-footer">
        <span>
          {filtered.length ? safePage * limit + 1 : 0}–
          {Math.min((safePage + 1) * limit, filtered.length)} of {filtered.length} workflows
          <span className="subtle-note"> · Example records</span>
        </span>
        <div>
          <Button
            variant="outline"
            size="icon"
            aria-label="Previous page"
            disabled={safePage === 0}
            onClick={() => setPage(safePage - 1)}
          >
            <ChevronLeft />
          </Button>
          <span>{safePage + 1}</span>
          <Button
            variant="outline"
            size="icon"
            aria-label="Next page"
            disabled={safePage === maxPage}
            onClick={() => setPage(safePage + 1)}
          >
            <ChevronRight />
          </Button>
        </div>
      </div>
      <WorkflowComparison workflows={workflows.filter(w => compareIds.includes(w.id))} open={comparing} onClose={() => setComparing(false)} />
    </div>
  );
}
