import { createFileRoute } from '@tanstack/react-router';
import { SettingsPage } from '@/components/cube/settings';
export const Route = createFileRoute('/settings')({
  head: () => ({ meta: [
    { title: 'System Settings — CUBE Control Tower' },
    { name: 'description', content: 'Manage CUBE appearance, density, motion and source-update preferences.' },
    { property: 'og:title', content: 'System Settings — CUBE Control Tower' },
    { property: 'og:description', content: 'Personal workspace controls and read-only integration configuration.' },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' },
  ] }), component: SettingsPage,
});